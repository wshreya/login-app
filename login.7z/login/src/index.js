import React, {Component} from 'react';
import ReactDOM from 'react-dom';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom';
import { Provider } from "react-redux";
import store from "./redux/store";
import './index.css';
import App from './App';
import registerServiceWorker from './registerServiceWorker';


class Main extends Component{
	

	render(){
			return(
				<Router>
					<Switch>
						<Route exact path="/" component={App}/>
						<Route component={Main}/>
					</Switch>
				</Router>
			)
		}
	}


ReactDOM.render(
<Provider store={store}>
    <App />
</Provider>,
  document.getElementById("root"));
registerServiceWorker();
