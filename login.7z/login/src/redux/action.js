const getUserName = (userName) => 
    {
         return dispatch => {
             console.log('getUserName');
             dispatch ({type: "USER_NAME", payload: userName}) 
            }
    };

const storeWeatherData = (weatherData) => 
{
        return dispatch => {
            console.log('storeWeatherData');
            dispatch ({type: "WEATHER_MAIN", payload: weatherData}) 
        }
};


module.exports = {getUserName,storeWeatherData}