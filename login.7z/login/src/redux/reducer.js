const initialState = {
    userName: '',
    weatherData:{},
  };
  const rootReducer = (state = initialState, action) => {
      console.log('rootReducer'+state.userName);
      switch (action.type) {
        case "USER_NAME":
            return { ...state, userName: state.userName + action.payload };
        case "WEATHER_MAIN":
            return { ...state, weatherData: action.payload };
        
      }
      return state;
  };

  export default rootReducer;