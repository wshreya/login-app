import React , {Component} from 'react';
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import {storeWeatherData} from "../redux/action";
import axios from 'axios';
import WeatherTable from './weathertable';
import styles from '../style/dashboard.css';

class Dashboard extends Component {

    constructor(props) {
        super(props);
        this.state={
            "weatherData":{},
            "city":''
        }
        this.setData = this.setData.bind(this);
        this.updateCity = this.updateCity.bind(this);
        this.searchWeather = this.searchWeather.bind(this);
    }

    updateCity(e) {
        this.setState({city:e.target.value});
    }

    setData(data) {
        this.setState({weatherData:data});
        this.props.storeWeatherData(this.state.weatherData);
        console.log(this.state.weatherData.main);
      }

    searchWeather () {
        console.log(this.state.city);
        var th=this;
        this.serverRequest =
          axios.get("http://api.openweathermap.org/data/2.5/weather?q="+this.state.city+"&appid=e92066829eaa6dff702761a84f98cdbd")
            .then(function(response) {
                console.log(response.data);    
                th.setData(response.data);
                //console.log(th.state.weatherData);
            })
      }

    render() {
        if (this.state.weatherData) {

        return (
            <div className="container"><br/>
                 {/* <div className="row"><label className="control-label col-md-2 col-md-offset-4">{this.state.weatherData.name}</label> </div> */}
                 <div className="row">
                    <div className="col-md-1 col-md-offset-5">
                        <label className="control-label">City :</label>
                    </div>
                    <div className="col-md-5">
                        <input type="text" className="form-control" id="city" placeholder="Enter email" name="email" 
                         value={this.state.city} onChange = {this.updateCity}/>
                    </div>
                    <div className="col-md-1">        
                        <div className="col-md-offset-2 col-md-5">
                            <button className="btn btn-default" onClick = {this.searchWeather}>Submit</button>
                    </div>
                </div>
                </div>
                 <WeatherTable/> 
          </div>
        );
      }
      else {
        <div className="row"><br/><br/><br/><br/><br/>
        <label className="control-label col-md-2 col-md-offset-4">Welcome to dash page ...Please wait..</label>
 </div>
      }
    }
}

    const mapStateToProps = state => {
        return { userName: state.userName };
    };
    const mapDispatchToProps = (dispatch) => {
        return bindActionCreators({storeWeatherData},dispatch);
           // getUserName: userName => dispatch(getUserName(userName))
        
      }

export default connect(mapStateToProps,mapDispatchToProps)(Dashboard);