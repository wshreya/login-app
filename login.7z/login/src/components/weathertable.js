import React , {Component} from 'react';
import PropTypes from 'prop-types';
import { connect } from "react-redux";
import styles from '../style/weather.css';

class WeatherTable extends Component {

    componentWillReceiveProps(newProps) {  
        console.log(newProps);
     }
    
    

    render() {
        return (
            <div className="">
            {this.props.weatherData && this.props.weatherData.weather ?
            <div className={'container ' + this.props.weatherData.weather[0].main}>
            <div className="row">
                <span>{this.props.weatherData.name} : {this.props.weatherData.weather[0].description}</span></div>
                 <table className="table table-bordered">
                 {this.props.weatherData && this.props.weatherData.main && this.props.weatherData.weather[0] ? <tbody>
        
      <tr>
        <td>Temperature</td>
            <td>{this.props.weatherData.main.temp}</td> 
      </tr> 
      
       <tr>
        <td>Pressure</td>
        <td>{this.props.weatherData.main.pressure} hpa</td>
      </tr> 
      <tr>
        <td>Humidity</td>
        <td>{this.props.weatherData.main.humidity} %</td>
      </tr> 
                </tbody>: ""
        }
  </table></div> : "" }
          </div>
        );
      }
    }

     const mapStateToProps = state => {
         console.log(state.weatherData);
        return { weatherData: state.weatherData,weather: state.weather };
    };
    

export default connect(mapStateToProps)(WeatherTable);