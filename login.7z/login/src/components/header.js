import React from 'react';
import { connect } from "react-redux";
import style from '../style/header.css';

const Header = (props) => {
    return (
//     <nav className="navbar navbar-inverse navbar-fixed-top">
//         <div className="container-fluid">
//             <div className="navbar-header">
//                  <span className="navbar-brand" href="#">Login App</span>
//             </div>
//             <ul className="nav navbar-nav navbar-right">
//             { props.userName !== ''
//                 ? <li><a href=""><span className="glyphicon glyphicon-user"></span> Welcome {props.userName}</a></li>
//                 : <span></span>
//             }
//             </ul>
//         </div>
// </nav>


<nav className="navbar navbar-inverse">
<div className="container-fluid">
  <div className="navbar-header">
    <a className="navbar-brand" href="#">Login App</a>
  </div>
  <ul className="nav navbar-nav navbar-right">
            { props.userName !== ''
                ? <li><a href=""><span className="glyphicon glyphicon-user"></span> Welcome {props.userName}</a></li>
                : <li><span></span></li>
            }
             </ul>
</div>
</nav>


      );
} 
const mapStateToProps= state => {  
    return {userName : state.userName};
};


export default connect(mapStateToProps)(Header);


